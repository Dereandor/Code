Kjørte wireshark ved forsøk av både ntnu epostog gmail, men fikk bare TCP krypterte pakker i filteret, så klarte ikke finne igjen passord i noen av pakkene.
