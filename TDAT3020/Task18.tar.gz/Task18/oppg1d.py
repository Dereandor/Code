a = 11**72

print(a)

b = 11**136

print(b)

c = a * b

print(c)

print(c % 10001)