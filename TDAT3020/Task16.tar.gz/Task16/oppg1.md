Oppgave 1
a) Gitt følgende rekursive følge/LFSR:
zi+4 = zi + zi+1 + zi+2 + zi+3(mod 2)
Hva blir perioden med nøklene
1 K = 1000
2 K = 0011
3 K = 1111


1) 1000110001|100011000110001100011000


2) 0011000110|

3) 1111011110|


b) Gjør det samme for følgende LFSR:
zi+4 = zi + zi+3(mod 2)

1) 10001111010110010

2) 00111101011001100

3) 11110101100100011110
