a)

    n = 1829
    B = 5
    Pollard p-1 = 31

b)

    n_1 = 18779
    n_1B = 211
    n_2 = 42583
    n_2B = 439

    B = 7
    B = 6

c)

    B = 7