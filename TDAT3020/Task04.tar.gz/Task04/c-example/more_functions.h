void another_function();

void yet_another_function();
