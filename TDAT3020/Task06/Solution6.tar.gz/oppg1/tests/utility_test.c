#include "utility.h"
#include <assert.h>
#include <string.h>

int main() {
  char *str = "&";
  char *equal = "&amp";
  assert(replace(str, "&", "&amp") == equal);

  char *str2 = "Hello & < > & < >";
  char *equal2 = "Hello &amp &lt &gt &amp &lt &gt";
  assert(replacer(str2) == equal2);
}
