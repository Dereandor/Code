1)

    6, 6^40 (mod 41) = 1


2)


3)

    Hvis Z_p ikke er syklisk så finnes det ingen prmitive elementer mod p
    Z_p er syklisk kun hvis p er 2, 4, n^k eller 2n^k der n er et odde primtall.

4)

    Z41 har 16 primitive elementer = 6, 7, 11, 12, 13, 15, 17, 19, 22, 24, 26, 28, 29, 30, 34 og 35.