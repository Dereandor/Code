find . -name "*.jpg" -exec ./flyttjpg {} \;
