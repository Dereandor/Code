#include "a_function.h"
#include <stdio.h>

void a_function(char *message) {
  printf("message from a_function: %s", message);
}
