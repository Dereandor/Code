#include "utility.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
  char *str = "Hello & welcome < user >";
  printf("%s\n", str);
  printf("%s\n", replacer(str));
}