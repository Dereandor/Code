#include "more_functions.h"
#include <stdio.h>

void another_function() {
  printf("You have called another_function\n");
}

void yet_another_function() {
  printf("You have called yet_another_function\n");
}
